<?php

namespace WP_SMS\Admin\Notification;

use Exception;
use WP_SMS\Components\RemoteRequest;

class NotificationFetcher
{
    /**
     * API base URL for fetching notifications.
     *
     * @var string
     */
    private $apiUrl = 'https://connect.wsms.io';

    /**
     * Fetches notifications from the remote API and stores them in the WordPress database.
     *
     * @return bool True on success, false on failure.
     * @throws Exception If the API response is invalid or an error occurs.
     */
    public function fetchNotification()
    {
        try {
            $pluginSlug = basename(dirname(WP_SMS_MAIN_FILE));
            $url        = $this->apiUrl . '/api/v1/notifications';
            $method     = 'GET';
            $args       = ['plugin_slug' => $pluginSlug, 'per_page' => 20, 'sortby' => 'activated_at-desc'];
            $params     = [
                'timeout'     => 45,
                'redirection' => 5,
                'headers'     => array(
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json; charset=utf-8',
                    'user-agent'   => $pluginSlug,
                ),
                'cookies'     => array(),
            ];

            $remoteRequest = new RemoteRequest($method, $url, $args, $params);

            $remoteRequest->execute(false, false);

            $response     = $remoteRequest->getResponseBody();
            $responseCode = $remoteRequest->getResponseCode();

            if ($responseCode !== 200) {
                return false;
            }

            $notifications = json_decode($response, true);

            if (empty($notifications) || !is_array($notifications)) {
                throw new Exception(
                // translators: %s: is the API URL that returned an empty response.
                    sprintf(__('No notifications were found. The API returned an empty response from the following URL: %s', 'wp-sms'), "{$this->apiUrl}/api/v1/notifications?plugin_slug={$pluginSlug}")
                );
            }

            $notifications = NotificationProcessor::syncNotifications($notifications);
            $notifications = NotificationProcessor::sortNotificationsByActivatedAt($notifications);

            $prevRawNotificationsData = NotificationFactory::getRawNotificationsData();

            if (!update_option('wp_sms_notifications', $notifications)) {
                if ($prevRawNotificationsData !== $notifications) {
                    WPSms()->log('Failed to update wp_sms_notifications option.', 'error');
                }
            }

            return true;

        } catch (Exception $e) {
            WPSms()->log($e->getMessage(), 'error');
            return false;
        }
    }
}