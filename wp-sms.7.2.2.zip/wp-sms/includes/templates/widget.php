<?php if (!defined('ABSPATH')) exit; // Exit if accessed directly ?>
<p>
    <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title', 'wp-sms'); ?></label>
    <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" dir="auto" value="<?php echo esc_attr($title); ?>">
</p>

<p>
    <label for="<?php echo esc_attr($this->get_field_id('description')); ?>"><?php esc_html_e('Description', 'wp-sms'); ?></label>
    <textarea class="widefat" dir="auto" id="<?php echo esc_attr($this->get_field_id('description')); ?>" name="<?php echo esc_attr($this->get_field_name('description')); ?>"><?php echo esc_attr($description); ?></textarea><p class="description"><?php esc_html_e('HTML code is valid.', 'wp-sms'); ?></p></p>
