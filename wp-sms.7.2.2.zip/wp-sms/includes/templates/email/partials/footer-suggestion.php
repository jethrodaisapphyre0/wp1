<?php if (!defined('ABSPATH')) exit; // Exit if accessed directly ?>
<div class="pro-ad">
    <table>
        <tr>
            <td><h3><?php esc_html_e('Upgrade to WP SMS Pro', 'wp-sms'); ?></h3></td>
            <td class="button">
                <a target="_blank" href="<?php echo esc_url(WP_SMS_SITE . '/pricing'); ?>"><?php esc_html_e('Buy Now ', 'wp-sms'); ?><img src="<?php echo esc_url(WP_SMS_URL . 'public/images/icons/white-chev.png'); ?>"/></a>
            </td>
        </tr>
    </table>
    <p><?php esc_html_e('Get more features and better performance with WP SMS All-In-One', 'wp-sms'); ?></p>
</div>