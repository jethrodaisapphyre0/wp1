<?php
	/*
   * @Author 		engr.sumonazma@gmail.com
   * Copyright: 	mage-people.com
   */
	if ( ! defined( 'ABSPATH' ) ) {
		die;
	} // Cannot access pages directly.
	if ( ! class_exists( 'MPWEM_Custom_Layout' ) ) {
		class MPWEM_Custom_Layout {
			public function __construct() {
				add_action( 'add_mpwem_hidden_table', array( $this, 'hidden_table' ), 10, 2 );
				add_action( 'add_mpwem_pagination_section', array( $this, 'pagination' ), 10, 3 );
			}
			public function hidden_table( $hook_name, $data = array() ) {
				?>
                <div class="mpwem_hidden_content">
                    <table>
                        <tbody class="mpwem_hidden_item">
						<?php do_action( $hook_name, $data ); ?>
                        </tbody>
                    </table>
                </div>
				<?php
			}
			public function pagination( $params, $total_item, $active_page = 1 ) {
				ob_start();
				$per_page = $params['show'] > 1 ? $params['show'] : $total_item;
				?>
                <input type="hidden" name="pagination_per_page" value="<?php echo esc_attr( $per_page ); ?>"/>
                <input type="hidden" name="pagination_style" value="<?php echo esc_attr( $params['pagination-style'] ); ?>"/>
                <input type="hidden" name="mp_total_item" value="<?php echo esc_attr( $total_item ); ?>"/>
				<?php if ( $total_item > $per_page ) { ?>
                    <div class="allCenter pagination_area" data-placeholder>
						<?php
							if ( $params['pagination-style'] == 'load_more' ) {
								?>
                                <button type="button" class="_button_general_xs_min_200 pagination_load_more" data-load-more="0">
									<?php esc_html_e( 'Load More', 'mage-eventpress' ); ?>
                                </button>
								<?php
							} else {
								$page_mod     = $total_item % $per_page;
								$total_page   = (int) ( $total_item / $per_page ) + ( $page_mod > 0 ? 1 : 0 );
								$current_page = $active_page < 5 ? 1 : $active_page - 4;
								$last_page    = $active_page < 5 ? min( 9, $total_page ) : $active_page + 5;
								?>
                                <div class="buttonGroup">
									<?php if ( $total_page > 2 ) { ?>
                                        <button class="_button_general_xs page_prev" type="button" title="<?php esc_html_e( 'GoTO Previous Page', 'mage-eventpress' ); ?>">
                                            <span class="fas fa-chevron-left _mp_zero"></span>
                                        </button>
									<?php } ?>

									<?php if ( $total_page > 9 && $active_page > 5 ) { ?>
                                        <button class="_button_general_xs ellipse_left" type="button" disabled>
                                            <span class="fas fa-ellipsis-h _mp_zero"></span>
                                        </button>
									<?php } ?>

									<?php for ( $i = $current_page; $i <= $last_page; $i ++ ) { ?>
                                        <button class="_button_general_xs <?php echo esc_html( $i ) == $active_page ? 'active_pagination' : ''; ?>" type="button" data-pagination="<?php echo esc_html( $i ); ?>"><?php echo esc_html( $i ); ?></button>
									<?php } ?>

									<?php if ( $total_page > 9 && $active_page < ( $total_page - 5 ) ) { ?>
                                        <button class="_button_general_xs ellipse_right" type="button" disabled>
                                            <span class="fas fa-ellipsis-h _mp_zero"></span>
                                        </button>
									<?php } ?>

									<?php if ( $total_page > 2 ) { ?>
                                        <button class="_button_general_xs page_next" type="button" title="<?php esc_html_e( 'GoTO Next Page', 'mage-eventpress' ); ?>">
                                            <span class="fas fa-chevron-right _mp_zero"></span>
                                        </button>
									<?php } ?>
                                </div>
							<?php } ?>
                    </div>
					<?php
				}
				echo ob_get_clean();
			}
			/*****************************/
			public static function switch_button( $name, $checked = '' ) {
				?>
                <label class="round_switch_label">
                    <input type="checkbox" name="<?php echo esc_attr( $name ); ?>" <?php echo esc_attr( $checked ); ?>>
                    <span class="round_switch" data-collapse-target="#<?php echo esc_attr( $name ); ?>"></span>
                </label>
				<?php
			}
			public static function show_hide_button( $name, $value = 'yes') {
				$close_text = $value == 'yes' ? __( 'Hide', 'mage-eventpress' ) : __( 'Show', 'mage-eventpress' );
				$open_text   = $value == 'yes' ? __( 'Show', 'mage-eventpress' ) : __( 'Hide', 'mage-eventpress' );
				$ticket_class = $value == 'yes' ? '_button_success_xxs' : '_button_danger_xxs';
				$open_icon = $value == 'yes' ? 'mi-unlock' : 'mi-lock';
				$close_icon = $value == 'yes' ? 'mi-lock' : 'mi-unlock';
				?>
                <button type="button" class="<?php echo esc_attr( $ticket_class ); ?> mpwem_show_hide_button" data-open-text="<?php echo esc_attr( $open_text ); ?>" data-close-text="<?php echo esc_attr( $close_text ); ?>" data-open-icon="<?php echo esc_attr( $open_icon ); ?>" data-close-icon="<?php echo esc_attr( $close_icon ); ?>">
                    <input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>">
                    <span data-icon="" class="mi  <?php echo esc_attr( $open_icon ); ?> _mr_xxs"></span>
                    <!-- <span data-text><?php //echo esc_html( $open_text ); ?></span> -->
                </button>
				<?php
			}
			public static function custom_checkbox( $name, $value = '', $title = '' ): void {
				?>
                <div class="checkbox_area">
                    <label class="checkbox_item <?php echo esc_attr( $value ); ?>" data-collapse-target="#<?php echo esc_attr( $name ); ?>">
                        <input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>">
                        <span class="checkbox_custom"></span>
                        <span><?php echo esc_html( $title ); ?></span>
                    </label>
                </div>
				<?php
			}
			public static function popup_button( $target_popup_id, $text ) {
				?>
                <button type="button" class="_button_default_bgBlue" data-target-popup="<?php echo esc_attr( $target_popup_id ); ?>">
                    <span class="fas fa-plus-square"></span>
					<?php echo esc_html( $text ); ?>
                </button>
				<?php
			}
			public static function popup_button_xs( $target_popup_id, $text ) {
				?>
                <button type="button" class="_button_default_xs_bgBlue" data-target-popup="<?php echo esc_attr( $target_popup_id ); ?>">
                    <span class="fas fa-plus-square"></span>
					<?php echo esc_html( $text ); ?>
                </button>
				<?php
			}
			/*****************************/
			public static function add_new_button( $button_text, $class = 'mpwem_add_item', $button_class = '_button_theme_xs_mt_xs', $icon_class = 'fas fa-plus-square' ) {
				?>
                <button class="<?php echo esc_attr( $button_class . ' ' . $class ); ?>" type="button">
                    <span class="<?php echo esc_attr( $icon_class ); ?>"></span>
                    <span class="_ml_xs"><?php echo esc_html( $button_text ); ?></span>
                </button>
				<?php
			}
			public static function move_remove_button() {
				?>
                <div class="allCenter">
                    <div class="buttonGroup">
						<?php
							self::remove_button();
							self::move_button();
						?>
                    </div>
                </div>
				<?php
			}
			public static function remove_button() {
				?>
                <button class="_button_warning_xs mpwem_item_remove" type="button">
                    <span class="fas fa-trash-alt _mp_zero"></span>
                </button>
				<?php
			}
			public static function move_button() {
				?>
                <div class="_button_navy_blue_xs mpwem_sortable_button" type="button">
                    <span class="fas fa-expand-arrows-alt _mp_zero"></span>
                </div>
				<?php
			}
			public static function add_multi_image( $name, $images ) {
				$images = is_array( $images ) ? MPWEM_Global_Function::array_to_string( $images ) : $images;
				?>
                <div class="mp_multi_image_area">
                    <input type="hidden" class="mp_multi_image_value" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $images ); ?>"/>
                    <div class="mp_multi_image">
						<?php
							$all_images = explode( ',', $images );
							if ( $images && is_array( $all_images ) && sizeof( $all_images ) > 0 ) {
								foreach ( $all_images as $image ) {
									?>
                                    <div class="mp_multi_image_item" data-image-id="<?php echo esc_attr( $image ); ?>">
                                        <span class="fas fa-times _icon_circle_xs mpwem_remove_multi_image"></span>
                                        <img src="<?php echo MPWEM_Global_Function::get_image_url( '', $image, 'medium' ); ?>" alt="<?php echo esc_attr( $image ); ?>"/>
                                    </div>
									<?php
								}
							}
						?>
                    </div>
                    <div class="">
						<?php MPWEM_Custom_Layout::add_new_button( esc_html__( 'Add Image', 'mage-eventpress' ), 'mpwem_add_multi_image', '_button_default_xs_bgColor_1' ); ?>
                    </div>
                </div>
				<?php
			}
			/*****************************/
			public static function bg_image( $post_id = '', $image_id = '', $size = 'full' ) {
				$image_url = MPWEM_Global_Function::get_image_url( $post_id, $image_id, $size );
				$image_url = $image_url ?: MPWEM_PLUGIN_URL . '/assets/helper/images/no_image.png';
				$size      = wp_getimagesize( $image_url );
				$width     = 0;
				$height    = 0;
				if ( $size ) {
					$width  = $size[0];
					$height = $size[1];
				}
				?>
                <div data-bg-image="<?php echo esc_html( $image_url ); ?>" data-width="<?php echo esc_attr( $width ); ?>" data-height="<?php echo esc_attr( $height ); ?>"></div>
                <!--                style="max-width:--><?php ////echo esc_attr( $width ); ?><!--px;max-height:  --><?php ////echo esc_attr( $height ); ?><!--px;"-->
				<?php
			}
			/*****************************/
			public static function load_more_text( $text = '', $length = 150 ) {
				$text_length = strlen( $text );
				if ( $text && $text_length > $length ) {
					?>
                    <div class="mpwem_load_more_text_area">
                        <span data-read-close><?php echo esc_html( substr( $text, 0, $length ) ); ?> ....</span>
                        <span data-read-open class="dNone"><?php echo esc_html( $text ); ?></span>
                        <div data-read data-open-text="<?php esc_attr_e( 'Load More', 'mage-eventpress' ); ?>" data-close-text="<?php esc_attr_e( 'Less More', 'mage-eventpress' ); ?>">
                            <span data-text><?php esc_html_e( 'Load More', 'mage-eventpress' ); ?></span>
                        </div>
                    </div>
					<?php
				} else {
					?>
                    <span><?php echo esc_html( $text ); ?></span>
					<?php
				}
			}
			/*****************************/
			public static function qty_input( $data = [] ) {
				//echo '<pre>';print_r($data);echo '</pre>';
				$input_name     = array_key_exists( 'name', $data ) ? $data['name'] : '';
				$price          = array_key_exists( 'price', $data ) ? $data['price'] : 0;
				$available_seat = array_key_exists( 'available', $data ) ? $data['available'] : 1;
				$default_qty    = array_key_exists( 'd_qty', $data ) ? $data['d_qty'] : 0;
				$min_qty        = array_key_exists( 'min_qty', $data ) ? $data['min_qty'] : 0;
				$min_qty        = max( $min_qty, 0 );
				$max_qty        = array_key_exists( 'max_qty', $data ) ? $data['max_qty'] : '';
				$input_type     = array_key_exists( 'type', $data ) ? $data['type'] : '';
				$must_min       = array_key_exists( 'must_min', $data ) ? $data['must_min'] : 'off';
				//$min_qty = max($default_qty, $min_qty);
				$max_qty = $max_qty > 0 ? $max_qty : $available_seat;
				$max_qty = min( $available_seat, $max_qty );
				if ( $max_qty >= $min_qty && $max_qty > 0 ) {
					if ( $input_type == 'dropdown' ) {
						$text = array_key_exists( 'text', $data ) ? $data['text'] : '';
						?>
                        <label>
                            <select class="formControl" name="<?php echo esc_attr( $input_name ); ?>" data-price="<?php echo esc_attr( $price ); ?>">
								<?php
									// Include 0 option if min_qty > 0
									if ( $must_min == 'off' ) { ?>
                                        <option value="0">0 <?php echo esc_html( $text ) ?></option>
									<?php }
									for ( $i = max( $min_qty, 1 ); $i <= $max_qty; $i ++ ) { ?>
                                        <option value="<?php echo esc_attr( $i ); ?>" <?php echo esc_attr( $i == $default_qty ? 'selected' : '' ); ?>><?php echo esc_html( $i . ' ' . $text ) ?></option>
									<?php } ?>
                            </select>
                        </label>
					<?php } else { ?>
                        <div class=" qtyIncDec">
                            <div class="decQty">
                                <i class="fas fa-minus"></i>
                            </div>
                            <label>
                                <input type="text"
                                       class="formControl inputIncDec number_validation"
                                       data-price="<?php echo esc_attr( $price ); ?>"
                                       name="<?php echo esc_attr( $input_name ); ?>"
                                       value="<?php echo esc_attr( max( $default_qty, $min_qty, 0 ) ); ?>"
                                       min="<?php echo esc_attr( $min_qty ); ?>"
                                       max="<?php echo esc_attr( $max_qty ); ?>"
                                       data-min-qty="<?php echo esc_attr( $must_min == 'off' ? 0 : $min_qty ); ?>"
                                       readonly
                                />
                            </label>
                            <div class="incQty">
                                <i class="fas fa-plus"></i>
                            </div>
                        </div>
						<?php
					}
				} else {
					?> <input type="hidden" name="<?php echo esc_attr( $input_name ); ?>" value="0"  data-price="<?php echo esc_attr( $price ); ?>"/><?php
					esc_html_e( 'Sorry, not available', 'mage-eventpress' );
				}
			}
		}
		new MPWEM_Custom_Layout();
	}