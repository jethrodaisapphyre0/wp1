<?php
    if (!defined('ABSPATH')) {
        die;
    } // Cannot access pages directly.
    $event_id = $event_id ?? 0;
    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
    $event_infos = $event_infos ?? [];
    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
    if ($event_id > 0) {
        $event_infos = MPWEM_Functions::get_all_info($event_id);
        $all_dates = MPWEM_Functions::get_dates($event_id);
        $upcoming_date = array_key_exists('upcoming_date', $event_infos) ? $event_infos['upcoming_date'] : '';
        $all_times = MPWEM_Functions::get_times($event_id, $all_dates, $upcoming_date);
        $_single_event_setting_sec = array_key_exists('single_event_setting_sec', $event_infos) ? $event_infos['single_event_setting_sec'] : [];
        $single_event_setting_sec = is_array($_single_event_setting_sec) && !empty($_single_event_setting_sec) ? $_single_event_setting_sec : [];
        $hide_time_details = array_key_exists('mep_event_hide_time_from_details', $single_event_setting_sec) ? $single_event_setting_sec['mep_event_hide_time_from_details'] : 'no';
        if ($hide_time_details == 'no' && $upcoming_date && MPWEM_Global_Function::check_time_exit_date($upcoming_date)) {
            $icon_setting_sec = array_key_exists('icon_setting_sec', $event_infos) ? $event_infos['icon_setting_sec'] : [];
            $icon_setting_sec = empty($icon_setting_sec) && !is_array($icon_setting_sec) ? [] : $icon_setting_sec;
            $mep_event_time_icon = array_key_exists('mep_event_time_icon', $icon_setting_sec) ? $icon_setting_sec['mep_event_time_icon'] : 'fas fa-clock';
            $date_type = get_post_meta($event_id, 'mep_enable_recurring', true) ? get_post_meta($event_id, 'mep_enable_recurring', true) : '';
            if ($date_type == 'no' || $date_type == 'yes') {
                $start_time = current($all_dates)['time'];
            } else {
                $date = current($all_dates);
                $all_times = MPWEM_Functions::get_times($event_id, $all_dates, $date);
                if (is_array($all_times) && sizeof($all_times) > 0) {
                    $time = current($all_times);
                    $time_info = array_key_exists('start', $time) ? $time['start'] : [];
                    if (is_array($time_info) && sizeof($time_info) > 0) {
                        $time = array_key_exists('time', $time_info) ? $time_info['time'] : '';
                        if ($time) {
                            $start_time = $date . ' ' . $time;
                        }
                    }
                }
            }
            if (MPWEM_Global_Function::check_time_exit_date($start_time)) {
                ?>
                <div class="short_item">
                    <h4 class="__icon_circle_mr"><span class="<?php echo esc_attr($mep_event_time_icon); ?>"></span></h4>
                    <div class="_fdColumn">
                        <h6><?php esc_html_e('Event Time:', 'mage-eventpress'); ?></h6>
                        <p><?php echo get_mep_datetime( $start_time, 'time' ); ?></p>

                    </div>
                </div>
                <?php
            }
        }
    }